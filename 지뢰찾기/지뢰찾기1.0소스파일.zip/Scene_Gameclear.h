#ifndef __SCENE_GAMECLEAR__
#define __SCENE_GAMECLEAR__


void Scene_Gameclear_Init();
bool Scene_Gameclear_Render(float timeDelta);

#endif